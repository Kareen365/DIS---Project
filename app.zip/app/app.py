from flask import Flask, render_template, request, redirect, flash, url_for, session, jsonify
import psycopg2
import bcrypt
from psycopg2.extras import RealDictCursor



conn = psycopg2.connect(dsn='postgresql://postgres:postgres@localhost:5432/dis')


app = Flask(__name__)

app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'


userLoginStmt = """
SELECT * FROM users
WHERE email = %s
LIMIT 1
"""


@app.post('/login')
def login_req():
    email = request.form['email']
    password = request.form['password']

    with conn.cursor() as cursor:
        cursor.execute(userLoginStmt, (email,))

        res = cursor.fetchone()
        if res == None:
            flash('No user with that email was found.')
            return redirect(url_for('login'))

        if not bcrypt.checkpw(password.encode('utf-8'), res[3].encode('utf-8')):
            flash('The password was incorrect.')
            return redirect(url_for('login'))

        session['user_id'] = res[0]

    conn.commit()

    return redirect(url_for('tasks'))


@app.get('/login')
def login():
    if 'user_id' in session:
        return redirect(url_for('tasks'))

    return render_template('login.jinja')


countUsersStmt = """
SELECT COUNT(*) FROM users WHERE username = %s OR email = %s
"""

userCreateStmt = """
INSERT INTO users (username, email, password) 
VALUES (%s, %s, %s)
RETURNING id
"""


@app.post('/register')
def register_req():
    username = request.form['username']
    email = request.form['email']
    password = request.form['password']

    with conn.cursor() as cursor:
        cursor.execute(countUsersStmt, (username, email))

        count_x = cursor.fetchone()
        if count_x[0] != 0:
            flash('Username or email already in use')
            return redirect(url_for('register'))

        salt = bcrypt.gensalt(14)
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)

        cursor.execute(userCreateStmt, (username, email, hashed.decode('utf-8')))

        user_id = cursor.fetchone()
        session['user_id'] = user_id[0]

    conn.commit()

    return redirect(url_for('tasks'))


@app.get('/register')
def register():
    if 'user_id' in session:
        return redirect(url_for('tasks'))

    return render_template('register.jinja')



@app.get('/tasks')
def tasks():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    return render_template('tasks.jinja')





@app.route('/tasks', methods=['GET'])
def list_tasks():
    c = conn.cursor(cursor_factory=RealDictCursor)
    c.execute('SELECT *FROM tasks ORDER BY id DESC')
    tasks = c.fetchall()
    conn.close()

    return render_template('tasks.jinja', tasks=tasks)

@app.post('/tasks')
def create_task():
    title = request.form['title']
    description = request.form['description']
    user_id = request.form['user_id']
        
    c = conn.cursor()
    c.execute('''
        INSERT INTO tasks (title, description, user_id)
        VALUES (%s, %s, %s)
    ''', (title, description, user_id))
    conn.commit()
    conn.close()
        
    return redirect('/tasks')


    

@app.route('/tasks/<int:id>', methods=['GET'])
def get_task(id):
    
    c = conn.cursor()
    c.execute('SELECT * FROM tasks WHERE id = ?', (id,))
    task = c.fetchone()
    conn.close()
    
    if task is None:
        return jsonify({'error': 'Task not found'}), 404
    
    return jsonify(dict(task))

@app.put('/tasks/<int:id>')
def update_task(id):
    title = request.form['title']
    description = request.form['description']
    c = conn.cursor()
    c.execute('''
        UPDATE tasks
        SET title = ?, description = ?
        WHERE id = ?
    ''', (title, description, id))
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Task updated'})

@app.delete('/tasks/<int:id>')
def delete_task(id):
    
    c = conn.cursor()
    c.execute('DELETE FROM tasks WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Task deleted'})

#@app.post('/clear-tasks')
#def clear_tasks():
    
 #   c = conn.cursor()
 #   c.execute('DELETE FROM tasks')
 #   conn.commit()
 #   conn.close()
 #   return redirect('/tasks')



#@app.before_request
#def handle_method_override():
 #   method = request.form.get('_method')
 #   if method:
 #       request.environ['REQUEST_METHOD'] = method.upper()




@app.get('/logout')
def logout():
    if 'user_id' in session:
        del session['user_id']

    return redirect(url_for('index'))


@app.get('/')
def index():
    return render_template('index.jinja')


if __name__ == '__main__':
    app.run(debug=True, port=8080)
    conn.close()
