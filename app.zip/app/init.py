import psycopg2


conn = psycopg2.connect(dsn='postgresql://postgres:postgres@localhost:5432/dis')

userTableCreate = """
CREATE TABLE IF NOT EXISTS users (
    id serial primary key,
    username varchar(255) not null unique,
    email varchar(255) not null unique,
    password varchar(255) not null
);
"""

taskTableCreate = """
CREATE TABLE IF NOT EXISTS tasks (
    id serial primary key,
    title varchar(255) not null,
    description text not null,
    user_id int not null references users(id)
);
"""

with conn.cursor() as cursor:
    cursor.execute(userTableCreate)
    cursor.execute(taskTableCreate)
    conn.commit()

conn.close()


